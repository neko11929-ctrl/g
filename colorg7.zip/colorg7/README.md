# COLOR.G7

موقع خاص لمشاركة الفيديوهات بجودتها الأصلية. Next.js + Supabase + Cloudflare R2 + Vercel.

## الإعداد (من الهاتف)

### 1) Supabase
1. أنشئ مشروعاً في supabase.com.
2. SQL Editor: الصق محتوى `supabase/schema.sql` ثم Run.
3. Authentication > Users > Add user: بريدك وكلمة مرور قوية.
4. Authentication > Sign In / Providers: أوقف "Allow new users to sign up".
5. Project Settings > API: انسخ `Project URL` و`anon key` و`service_role key`.

### 2) Cloudflare R2
1. R2 > Create bucket (مثلاً `colorg7-videos`). اتركه خاصاً (لا تفعّل الوصول العام).
2. R2 > Manage API Tokens > Create: صلاحية Object Read & Write لهذا الـ bucket. انسخ Access Key و Secret.
3. انسخ Account ID (يظهر في صفحة R2).
4. Bucket > Settings > CORS Policy، الصق:
```json
[{"AllowedOrigins":["https://colorg7.com","https://www.colorg7.com","http://localhost:3000"],
  "AllowedMethods":["PUT","GET"],"AllowedHeaders":["*"],"MaxAgeSeconds":3600}]
```

### 3) تشغيل تجريبي (GitHub Codespaces)
1. أنشئ مستودعاً خاصاً (Private) على GitHub وافتحه في Codespaces.
2. ارفع محتوى المشروع إلى المستودع، ثم في Terminal: `npm install`
3. انسخ `.env.example` إلى `.env.local` واملأ القيم (ADMIN_EMAIL = نفس بريد مستخدم Supabase).
4. `npm run dev` ثم افتح `/admin/login`.

### 4) النشر على Vercel
1. vercel.com > Add New > Project > اختر المستودع.
2. Settings > Environment Variables: أضف كل متغيرات `.env.example`.
3. Settings > Domains: أضف `colorg7.com` واتبع تعليمات الـ DNS.

## المرحلة 2: خادم FFmpeg (التحويل التلقائي)
Vercel لا يشغّل FFmpeg للفيديوهات الثقيلة، لذلك يعمل التحويل على خادم صغير منفصل (مجلد `worker/`).
1. في Supabase SQL Editor نفّذ `supabase/phase2.sql` (فقط إن كنت نفّذت `schema.sql` قبل المرحلة 2).
2. على Railway (أو أي خدمة تشغّل Docker): New Project > Deploy from GitHub > نفس المستودع > Settings > Root Directory = `worker`.
3. أضف متغيرات الخادم: `WORKER_SECRET` (نص عشوائي طويل)، `SUPABASE_URL` (نفس Project URL)، `SUPABASE_SERVICE_ROLE_KEY`، `R2_ACCOUNT_ID`، `R2_ACCESS_KEY_ID`، `R2_SECRET_ACCESS_KEY`، `R2_BUCKET`.
4. فعّل Public Networking للخادم وانسخ رابطه، ثم أضف في Vercel (وفي `.env.local`): `WORKER_URL` = ذلك الرابط، و`WORKER_SECRET` = نفس النص.
5. في لوحة التحكم اختر "تحويل تلقائي"، ارفع الأصل، وحدّد الجودات. تظهر الحالة Processing ثم Completed أو Failed مع السبب.

قواعد التحويل: الجودة تُحسب بالضلع الأقصر (فيديو ريلز 1080x1920 = 1080p)، لا تُنشأ جودة أعلى من الأصل، وإن كان الأصل بنفس الجودة المطلوبة يُحفظ كما هو دون إعادة ضغط. يُحذف الملف الأصلي المؤقت بعد المعالجة. اختبار المنطق محلياً: `cd worker && node test.mjs` (يحتاج ffmpeg).

## ملاحظات
- لا يُنشر `.env.local` أبداً (موجود في `.gitignore`).
- الروابط عشوائية (`/v/xxxxxxxxxxx`)، غير مفهرسة، ويمكن إيقافها أو تحديد انتهاء لها.
- روابط التحميل الفعلية موقّعة وتنتهي بعد 15 دقيقة، ومفاتيح R2 لا تصل للمتصفح.
- المرحلة 2: خادم FFmpeg منفصل للتحويل التلقائي (Vercel لا يشغّل FFmpeg للفيديوهات الثقيلة).
