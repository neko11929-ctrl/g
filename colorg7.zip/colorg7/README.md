# COLOR.G7

موقع خاص لمشاركة الفيديوهات بجودتها الأصلية. Next.js + Supabase + Cloudflare R2 + Vercel.

## الإعداد (من الهاتف)

### 1) Supabase
1. أنشئ مشروعاً في supabase.com.
2. SQL Editor: الصق محتوى `supabase/schema.sql` ثم Run.
3. Authentication > Users > Add user: بريدك وكلمة مرور قوية.
4. Authentication > Sign In / Providers: أوقف "Allow new users to sign up".
5. Project Settings > API: انسخ `Project URL` و`anon key` و`service_role key`.

### 2) Cloudflare R2
1. R2 > Create bucket (مثلاً `colorg7-videos`). اتركه خاصاً (لا تفعّل الوصول العام).
2. R2 > Manage API Tokens > Create: صلاحية Object Read & Write لهذا الـ bucket. انسخ Access Key و Secret.
3. انسخ Account ID (يظهر في صفحة R2).
4. Bucket > Settings > CORS Policy، الصق:
```json
[{"AllowedOrigins":["https://colorg7.com","https://www.colorg7.com","http://localhost:3000"],
  "AllowedMethods":["PUT","GET"],"AllowedHeaders":["*"],"MaxAgeSeconds":3600}]
```

### 3) تشغيل تجريبي (GitHub Codespaces)
1. أنشئ مستودعاً خاصاً (Private) على GitHub وافتحه في Codespaces.
2. ارفع محتوى المشروع إلى المستودع، ثم في Terminal: `npm install`
3. انسخ `.env.example` إلى `.env.local` واملأ القيم (ADMIN_EMAIL = نفس بريد مستخدم Supabase).
4. `npm run dev` ثم افتح `/admin/login`.

### 4) النشر على Vercel
1. vercel.com > Add New > Project > اختر المستودع.
2. Settings > Environment Variables: أضف كل متغيرات `.env.example`.
3. Settings > Domains: أضف `colorg7.com` واتبع تعليمات الـ DNS.

## ملاحظات
- لا يُنشر `.env.local` أبداً (موجود في `.gitignore`).
- الروابط عشوائية (`/v/xxxxxxxxxxx`)، غير مفهرسة، ويمكن إيقافها أو تحديد انتهاء لها.
- روابط التحميل الفعلية موقّعة وتنتهي بعد 15 دقيقة، ومفاتيح R2 لا تصل للمتصفح.
- المرحلة 2: خادم FFmpeg منفصل للتحويل التلقائي (Vercel لا يشغّل FFmpeg للفيديوهات الثقيلة).
