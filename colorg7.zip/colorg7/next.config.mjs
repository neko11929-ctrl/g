const noindex = [{ key: 'X-Robots-Tag', value: 'noindex, nofollow' }]
export default {
  poweredByHeader: false,
  eslint: { ignoreDuringBuilds: true },
  async headers() {
    return [
      { source: '/v/:path*', headers: noindex },
      { source: '/admin/:path*', headers: noindex },
      { source: '/api/:path*', headers: noindex },
    ]
  },
}
