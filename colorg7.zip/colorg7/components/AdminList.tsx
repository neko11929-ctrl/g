'use client'
import Link from 'next/link'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { createBrowserClient } from '@supabase/ssr'
import { qInfo, qIndex } from '@/lib/q'
export default function AdminList({ videos }: { videos: any[] }) {
  const r = useRouter()
  const [msg, setMsg] = useState('')
  const working = videos.some((v) => v.video_files.some((f: any) => f.status === 'processing'))
  useEffect(() => { if (!working) return; const t = setInterval(() => r.refresh(), 5000); return () => clearInterval(t) }, [working, r])
  const url = (c: string) => `${location.origin}/v/${c}`
  const call = async (id: string, method: string, body?: any) => {
    await fetch(`/api/admin/videos/${id}`, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })
    r.refresh()
  }
  const copy = async (c: string) => { await navigator.clipboard.writeText(url(c)); setMsg('تم نسخ الرابط') }
  const share = async (c: string, title: string) => { if (navigator.share) { try { await navigator.share({ title, url: url(c) }) } catch {} } else copy(c) }
  const del = (id: string) => { if (confirm('حذف الفيديو وكل ملفاته نهائياً؟')) call(id, 'DELETE') }
  const out = async () => { await createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!).auth.signOut(); r.replace('/admin/login'); r.refresh() }
  const b = 'h-10 rounded-full border border-neutral-700 px-4 text-sm active:scale-95'
  return (
    <section className="mt-8">
      <p role="status" className="mb-3 min-h-5 text-sm text-neutral-400">{msg}</p>
      {videos.length === 0 && <p className="text-neutral-400">لا توجد فيديوهات بعد. أضف أول فيديو.</p>}
      <div className="flex flex-col gap-4">
        {videos.map((v) => {
          const expired = v.expires_at && new Date(v.expires_at) < new Date()
          const qs = v.video_files.filter((f: any) => qInfo(f.quality)).sort((a: any, b: any) => qIndex(a.quality) - qIndex(b.quality))
          return (
            <article key={v.id} className="rounded-2xl border border-neutral-800 bg-neutral-900 p-4">
              <h2 className="font-medium">{v.title}</h2>
              <p className="mt-1 text-sm text-neutral-400">
                {!v.enabled ? 'الرابط متوقف' : expired ? 'الرابط منتهي' : 'الرابط فعّال'} · {v.views} مشاهدة · {v.downloads} تحميل
              </p>
              <p dir="ltr" className="mt-1 text-sm text-neutral-500">{qs.map((f: any) => qInfo(f.quality)!.label + (f.status === 'processing' ? ' (Processing)' : f.status === 'failed' ? ' (Failed)' : '')).join(' / ') || '—'}</p>
              {qs.filter((f: any) => f.status === 'failed').map((f: any) => <p key={f.quality} className="mt-1 text-sm text-red-400">{qInfo(f.quality)!.label}: {f.error || 'فشل التحويل'}</p>)}
              <div className="mt-4 flex flex-wrap gap-2">
                <button className={b} onClick={() => copy(v.code)}>نسخ الرابط</button>
                <button className={b} onClick={() => share(v.code, v.title)}>مشاركة</button>
                <Link className={b + ' inline-flex items-center'} href={`/admin/${v.id}`}>تعديل</Link>
                <button className={b} onClick={() => call(v.id, 'PATCH', { enabled: !v.enabled })}>{v.enabled ? 'إيقاف الرابط' : 'تفعيل الرابط'}</button>
                <button className={b + ' text-red-400'} onClick={() => del(v.id)}>حذف</button>
              </div>
            </article>
          )
        })}
      </div>
      <button onClick={out} className="mt-10 text-sm text-neutral-500">تسجيل الخروج</button>
    </section>
  )
}
