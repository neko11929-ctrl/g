'use client'
import { useState } from 'react'
export default function Actions({ code, l, ig }: { code: string; l: Record<string, string>; ig: string }) {
  const [msg, setMsg] = useState('')
  const link = () => `${location.origin}/v/${code}`
  const copy = async () => { await navigator.clipboard.writeText(link()); setMsg(l.copied) }
  const share = async () => {
    if (navigator.share) { try { await navigator.share({ title: 'COLOR.G7', url: link() }) } catch {} } else copy()
  }
  const report = async () => {
    await fetch('/api/report', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ code }) })
    setMsg(l.reported)
  }
  const b = 'inline-flex h-11 items-center rounded-full border border-neutral-700 px-5 text-sm transition hover:border-white active:scale-95'
  return (
    <div className="mt-8">
      <div className="flex flex-wrap gap-3">
        <button onClick={copy} className={b}>{l.copy}</button>
        <button onClick={share} className={b}>{l.share}</button>
        <a href={ig} target="_blank" rel="noopener" className={b}>{l.follow}</a>
        <a href="/" className={b}>{l.home}</a>
        <button onClick={report} className={b + ' text-neutral-400'}>{l.report}</button>
      </div>
      <p role="status" className="mt-3 min-h-5 text-sm text-neutral-400">{msg}</p>
    </div>
  )
}
