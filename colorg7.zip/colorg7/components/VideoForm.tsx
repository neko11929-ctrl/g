'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { QUALITIES, fmtSize } from '@/lib/q'

const api = async (path: string, method: string, body?: any) => {
  const r = await fetch(path, { method, headers: { 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined })
  const j = await r.json().catch(() => ({}))
  if (!r.ok) throw new Error(j.error || 'حدث خطأ، حاول مرة أخرى')
  return j
}
// Read the duration in the browser (no heavy processing, just metadata).
const duration = (f: File) =>
  new Promise<number>((res) => {
    const v = document.createElement('video')
    v.preload = 'metadata'
    v.onloadedmetadata = () => { res(Math.round(v.duration) || 0); URL.revokeObjectURL(v.src) }
    v.onerror = () => res(0)
    v.src = URL.createObjectURL(f)
  })
// Direct browser-to-R2 upload with progress.
const put = (url: string, f: File, type: string, onp: (p: number) => void) =>
  new Promise<void>((ok, no) => {
    const x = new XMLHttpRequest()
    x.open('PUT', url)
    x.setRequestHeader('Content-Type', type)
    x.upload.onprogress = (e) => e.lengthComputable && onp(Math.round((e.loaded / e.total) * 100))
    x.onload = () => (x.status < 300 ? ok() : no(new Error('رفض التخزين الملف (' + x.status + '). راجع إعدادات CORS في R2.')))
    x.onerror = () => no(new Error('تعذّر الاتصال بالتخزين. راجع إعدادات CORS في R2 أو اتصالك بالإنترنت.'))
    x.send(f)
  })

export default function VideoForm({ video }: { video: any | null }) {
  const r = useRouter()
  const [title, setTitle] = useState(video?.title ?? '')
  const [desc, setDesc] = useState(video?.description ?? '')
  const [expires, setExpires] = useState(video?.expires_at?.slice(0, 10) ?? '')
  const [thumb, setThumb] = useState<File | null>(null)
  const [files, setFiles] = useState<Record<string, File>>({})
  const [mode, setMode] = useState<'manual' | 'auto'>('manual')
  const [src, setSrc] = useState<File | null>(null)
  const [auto, setAuto] = useState<string[]>(['4k', '2k', '1080p'])
  const [label, setLabel] = useState('')
  const [pct, setPct] = useState(0)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const existing: any[] = video?.video_files ?? []

  async function save(e: React.FormEvent) {
    e.preventDefault()
    setErr('')
    if (mode === 'auto' ? !src || !auto.length : !video && !Object.keys(files).length) return setErr(mode === 'auto' ? 'اختر الملف الأصلي وجودة واحدة على الأقل' : 'أضف ملف فيديو واحداً على الأقل')
    setBusy(true)
    try {
      const first = mode === 'auto' ? src : Object.values(files)[0]
      const meta: any = { title, description: desc, expires_at: expires ? new Date(expires + 'T23:59:59').toISOString() : null }
      if (first) meta.duration_sec = await duration(first)
      const id: string = video ? (await api(`/api/admin/videos/${video.id}`, 'PATCH', meta), video.id) : (await api('/api/admin/videos', 'POST', meta)).id
      const jobs: [string, File, string?][] = []
      if (thumb) jobs.push(['thumb', thumb])
      if (mode === 'auto') jobs.push(['source', src!])
      else for (const [q, f] of Object.entries(files)) jobs.push(['video', f, q])
      for (const [kind, f, q] of jobs) {
        const type = f.type || (kind === 'thumb' ? 'image/jpeg' : 'video/mp4')
        setLabel(kind === 'thumb' ? 'الصورة المصغرة' : kind === 'source' ? 'الملف الأصلي' : QUALITIES.find((x) => x.id === q)!.label)
        setPct(0)
        const { key, url } = await api('/api/admin/upload-url', 'POST', { videoId: id, kind, quality: q, contentType: type, size: f.size })
        await put(url, f, type, setPct)
        if (kind === 'source') await api('/api/admin/convert', 'POST', { videoId: id, sourceKey: key, qualities: auto })
        else await api('/api/admin/files', 'POST', { videoId: id, kind, quality: q, key })
      }
      r.push('/admin')
      r.refresh()
    } catch (x: any) {
      setErr(x.message)
    } finally {
      setBusy(false)
    }
  }
  async function removeFile(id: string) {
    if (!confirm('حذف هذه الجودة؟')) return
    await api(`/api/admin/files?id=${id}`, 'DELETE')
    r.refresh()
  }
  const inp = 'w-full rounded-xl border border-neutral-800 bg-neutral-900 px-4 outline-none focus:border-white'
  return (
    <form onSubmit={save} className="flex flex-col gap-5">
      <label className="flex flex-col gap-2 text-sm text-neutral-400">عنوان الفيديو
        <input required value={title} onChange={(e) => setTitle(e.target.value)} className={inp + ' h-12 text-base text-white'} />
      </label>
      <label className="flex flex-col gap-2 text-sm text-neutral-400">الوصف (اختياري)
        <textarea rows={3} value={desc} onChange={(e) => setDesc(e.target.value)} className={inp + ' py-3 text-base text-white'} />
      </label>
      <label className="flex flex-col gap-2 text-sm text-neutral-400">الصورة المصغرة (اختياري)
        <input type="file" accept="image/jpeg,image/png,image/webp" onChange={(e) => setThumb(e.target.files?.[0] ?? null)} className="text-white" />
      </label>
      <div className="flex gap-2" role="group" aria-label="طريقة إضافة الجودات">
        {([['manual', 'رفع الجودات يدوياً'], ['auto', 'تحويل تلقائي']] as const).map(([m, t]) => (
          <button key={m} type="button" onClick={() => setMode(m)} aria-pressed={mode === m}
            className={'h-11 flex-1 rounded-full border text-sm ' + (mode === m ? 'border-white bg-white text-black' : 'border-neutral-700')}>{t}</button>
        ))}
      </div>
      {mode === 'auto' && (
        <div className="flex flex-col gap-4 rounded-2xl border border-neutral-800 p-4">
          <label className="flex flex-col gap-2 text-sm text-neutral-400">الملف الأصلي (أعلى جودة لديك)
            <input type="file" accept="video/*" className="text-white" onChange={(e) => setSrc(e.target.files?.[0] ?? null)} />
          </label>
          <div className="flex flex-col gap-2">
            <p className="text-sm text-neutral-400">الجودات المطلوب إنشاؤها</p>
            {QUALITIES.map((q) => (
              <label key={q.id} className="flex h-10 items-center gap-3">
                <input type="checkbox" checked={auto.includes(q.id)} onChange={(e) => setAuto((p) => (e.target.checked ? [...p, q.id] : p.filter((x) => x !== q.id)))} className="h-5 w-5" />
                {q.label} <span dir="ltr" className="text-sm text-neutral-500">{q.sub}</span>
              </label>
            ))}
          </div>
          <p className="text-sm text-neutral-500">لا يُنشأ إلا ما يساوي جودة الأصل أو أقل منها. التحويل يتم على الخادم، ويمكنك إغلاق الصفحة بعد انتهاء الرفع.</p>
        </div>
      )}
      {mode === 'manual' && <fieldset className="flex flex-col gap-4">
        <legend className="mb-2 text-sm text-neutral-400">ملفات الفيديو (ارفع الجودات التي تريد إتاحتها فقط)</legend>
        {QUALITIES.map((q) => {
          const ex = existing.find((f) => f.quality === q.id && f.status === 'completed')
          return (
            <div key={q.id} className="rounded-2xl border border-neutral-800 p-4">
              <p className="font-medium">{q.label} <span dir="ltr" className="text-sm text-neutral-500">{q.sub}</span></p>
              {ex && (
                <p className="mt-1 text-sm text-neutral-400">
                  مرفوع: <span dir="ltr">{fmtSize(Number(ex.size_bytes))}</span>{' '}
                  <button type="button" onClick={() => removeFile(ex.id)} className="text-red-400">حذف</button>
                </p>
              )}
              <input type="file" accept="video/*" className="mt-3 w-full text-sm"
                onChange={(e) => { const f = e.target.files?.[0]; setFiles((p) => { const n = { ...p }; f ? (n[q.id] = f) : delete n[q.id]; return n }) }} />
            </div>
          )
        })}
      </fieldset>}
      <label className="flex flex-col gap-2 text-sm text-neutral-400">انتهاء صلاحية الرابط (اختياري)
        <input type="date" dir="ltr" value={expires} onChange={(e) => setExpires(e.target.value)} className={inp + ' h-12 text-base text-white'} />
      </label>
      {busy && (
        <div role="status" className="text-sm">
          <p>جارٍ رفع {label}: <span dir="ltr">{pct}%</span></p>
          <div className="mt-2 h-2 overflow-hidden rounded-full bg-neutral-800"><div className="h-full bg-white transition-all" style={{ width: pct + '%' }} /></div>
          <p className="mt-2 text-neutral-500">أبقِ الصفحة مفتوحة حتى ينتهي الرفع.</p>
        </div>
      )}
      {err && <p role="alert" className="text-sm text-red-400">{err}</p>}
      <button disabled={busy} className="h-12 rounded-full bg-white font-medium text-black active:scale-95 disabled:opacity-50">{video ? 'حفظ التغييرات' : 'رفع ونشر'}</button>
    </form>
  )
}
