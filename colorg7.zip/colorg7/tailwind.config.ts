import type { Config } from 'tailwindcss'
export default {
  content: ['./app/**/*.{ts,tsx}', './components/**/*.{ts,tsx}'],
  theme: { extend: { fontFamily: { sans: ['var(--font-lat)', 'var(--font-ar)', 'system-ui', 'sans-serif'] } } },
} satisfies Config
