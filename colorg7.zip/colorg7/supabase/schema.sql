create table videos (
  id uuid primary key default gen_random_uuid(),
  code text unique not null,
  title text not null,
  description text default '',
  thumb_key text,
  duration_sec int,
  enabled boolean not null default true,
  expires_at timestamptz,
  views int not null default 0,
  downloads int not null default 0,
  created_at timestamptz not null default now()
);
create table video_files (
  id uuid primary key default gen_random_uuid(),
  video_id uuid not null references videos(id) on delete cascade,
  quality text not null,
  r2_key text not null,
  size_bytes bigint not null default 0,
  status text not null default 'completed' check (status in ('processing','completed','failed')),
  created_at timestamptz not null default now(),
  unique (video_id, quality)
);
create table reports (
  id uuid primary key default gen_random_uuid(),
  video_id uuid references videos(id) on delete cascade,
  created_at timestamptz not null default now()
);
-- No policies on purpose: only the server (service role) can read or write.
alter table videos enable row level security;
alter table video_files enable row level security;
alter table reports enable row level security;
create function inc_views(p_id uuid) returns void language sql security definer set search_path = public
  as $$ update videos set views = views + 1 where id = p_id $$;
create function inc_downloads(p_id uuid) returns void language sql security definer set search_path = public
  as $$ update videos set downloads = downloads + 1 where id = p_id $$;
revoke execute on function inc_views(uuid), inc_downloads(uuid) from public, anon, authenticated;
