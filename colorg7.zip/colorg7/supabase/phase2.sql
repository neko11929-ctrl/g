-- Run once if you already ran schema.sql before phase 2
alter table video_files add column if not exists error text;
