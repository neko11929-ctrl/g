import { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand, HeadObjectCommand } from '@aws-sdk/client-s3'
import { getSignedUrl } from '@aws-sdk/s3-request-presigner'

const r2 = new S3Client({
  region: 'auto',
  endpoint: `https://${process.env.R2_ACCOUNT_ID}.r2.cloudflarestorage.com`,
  credentials: { accessKeyId: process.env.R2_ACCESS_KEY_ID!, secretAccessKey: process.env.R2_SECRET_ACCESS_KEY! },
})
const Bucket = () => process.env.R2_BUCKET!
export const putUrl = (Key: string, ContentType: string) =>
  getSignedUrl(r2, new PutObjectCommand({ Bucket: Bucket(), Key, ContentType }), { expiresIn: 3600 })
// Short-lived signed link. With a filename, the browser downloads instead of playing.
export const getUrl = (Key: string, filename?: string) =>
  getSignedUrl(
    r2,
    new GetObjectCommand({ Bucket: Bucket(), Key, ResponseContentDisposition: filename ? `attachment; filename="${filename}"` : undefined }),
    { expiresIn: 900 },
  )
export const delObj = (Key: string) => r2.send(new DeleteObjectCommand({ Bucket: Bucket(), Key })).catch(() => {})
export const sizeOf = async (Key: string) => (await r2.send(new HeadObjectCommand({ Bucket: Bucket(), Key }))).ContentLength ?? 0
