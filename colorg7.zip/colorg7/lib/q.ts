// Add a new quality here and it appears automatically in the admin form and on video pages.
export const QUALITIES = [
  { id: '4k', label: '4K', sub: '2160p' },
  { id: '2k', label: '2K', sub: '1440p' },
  { id: '1080p', label: 'Full HD', sub: '1080p' },
  { id: '720p', label: 'HD', sub: '720p' },
  { id: '480p', label: 'SD', sub: '480p' },
]
export const qIndex = (id: string) => QUALITIES.findIndex((q) => q.id === id)
export const qInfo = (id: string) => QUALITIES.find((q) => q.id === id)
export const fmtSize = (n: number) =>
  n >= 1073741824 ? (n / 1073741824).toFixed(2) + ' GB' : n >= 1048576 ? Math.round(n / 1048576) + ' MB' : Math.max(1, Math.round(n / 1024)) + ' KB'
export const fmtDur = (s?: number | null) => (s ? Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0') : '')
