import { createServerClient } from '@supabase/ssr'
import { createClient } from '@supabase/supabase-js'
import { cookies } from 'next/headers'

// Service-role client: server only, bypasses RLS. Never import in a client component.
export const db = () =>
  createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!, { auth: { persistSession: false } })

export async function isAdmin() {
  const store = cookies()
  const sb = createServerClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!, {
    cookies: {
      getAll: () => store.getAll(),
      setAll: (list) => {
        try { list.forEach(({ name, value, options }) => store.set(name, value, options)) } catch {}
      },
    },
  })
  const { data } = await sb.auth.getUser()
  return !!data.user && data.user.email === process.env.ADMIN_EMAIL
}
export const deny = () => Response.json({ error: 'غير مصرح' }, { status: 401 })
export const fail = (error: string, status = 400) => Response.json({ error }, { status })
