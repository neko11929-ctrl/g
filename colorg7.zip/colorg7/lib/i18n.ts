import { cookies } from 'next/headers'
export const IG = 'https://instagram.com/color.g7'
export type Lang = 'ar' | 'en'
export const getLang = (): Lang => (cookies().get('lang')?.value === 'en' ? 'en' : 'ar')
export const T = {
  ar: {
    tagline: 'فيديوهاتي بجودتها الأصلية.',
    about: 'مكتبة خاصة لتحميل فيديوهاتي بأعلى جودة. كل فيديو له رابط خاص أرسله لك مباشرة.',
    follow: 'تابعني على إنستغرام', home: 'الصفحة الرئيسية', download: 'تحميل', qualities: 'اختر الجودة',
    copy: 'نسخ الرابط', copied: 'تم نسخ الرابط', share: 'مشاركة', report: 'الإبلاغ عن رابط لا يعمل', reported: 'وصلنا بلاغك، شكراً',
    gone: 'هذا الرابط غير متاح', goneHint: 'ربما أُوقف أو انتهت صلاحيته. اطلب رابطاً جديداً من @color.g7.',
  },
  en: {
    tagline: 'My videos, in their original quality.',
    about: 'A private library for downloading my videos in the highest quality. Each video has its own private link that I send you directly.',
    follow: 'Follow on Instagram', home: 'Back to Home', download: 'Download', qualities: 'Choose a quality',
    copy: 'Copy Link', copied: 'Link copied', share: 'Share Video', report: 'Report Broken Link', reported: 'Report received, thank you',
    gone: 'This link is not available', goneHint: 'It may have been turned off or expired. Ask for a new link at @color.g7.',
  },
}
