import http from 'node:http'
import { timingSafeEqual, randomBytes } from 'node:crypto'
import { createWriteStream, createReadStream } from 'node:fs'
import { stat, rm, mkdtemp } from 'node:fs/promises'
import { pipeline } from 'node:stream/promises'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import { S3Client, GetObjectCommand, PutObjectCommand, CopyObjectCommand, DeleteObjectCommand } from '@aws-sdk/client-s3'
import { createClient } from '@supabase/supabase-js'
import { probe, decide, transcode, TARGETS } from './convert.mjs'

const env = (k) => { const v = process.env[k]; if (!v) throw new Error('Missing env ' + k); return v }
const Bucket = env('R2_BUCKET')
const SECRET = Buffer.from(env('WORKER_SECRET'))
const r2 = new S3Client({
  region: 'auto',
  endpoint: `https://${env('R2_ACCOUNT_ID')}.r2.cloudflarestorage.com`,
  credentials: { accessKeyId: env('R2_ACCESS_KEY_ID'), secretAccessKey: env('R2_SECRET_ACCESS_KEY') },
})
const sb = createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false } })
const setRow = (videoId, quality, patch) => sb.from('video_files').update(patch).eq('video_id', videoId).eq('quality', quality)

async function handle({ videoId, sourceKey, qualities }) {
  const dir = await mkdtemp(join(tmpdir(), 'job-'))
  try {
    const src = join(dir, 'source')
    const obj = await r2.send(new GetObjectCommand({ Bucket, Key: sourceKey }))
    await pipeline(obj.Body, createWriteStream(src))
    const info = await probe(src)
    const ext = sourceKey.split('.').pop()
    for (const q of qualities) {
      try {
        const target = TARGETS[q]
        const act = decide(info.short, target)
        if (act === 'skip') { await setRow(videoId, q, { status: 'failed', error: `الفيديو الأصلي (${info.short}p) أقل من ${target}p، لا يمكن رفع جودته` }); continue }
        const rnd = randomBytes(6).toString('hex')
        let key, size
        if (act === 'copy') { // already this quality: keep the untouched original
          key = `videos/${videoId}/${q}-${rnd}.${ext}`
          await r2.send(new CopyObjectCommand({ Bucket, Key: key, CopySource: `${Bucket}/${sourceKey}` }))
          size = (await stat(src)).size
        } else {
          const out = join(dir, `${q}.mp4`)
          await transcode(src, out, { portrait: info.portrait, target })
          size = (await stat(out)).size
          key = `videos/${videoId}/${q}-${rnd}.mp4`
          await r2.send(new PutObjectCommand({ Bucket, Key: key, Body: createReadStream(out), ContentLength: size, ContentType: 'video/mp4' }))
          await rm(out)
        }
        await setRow(videoId, q, { r2_key: key, size_bytes: size, status: 'completed', error: null })
      } catch (e) {
        console.error(videoId, q, e)
        await setRow(videoId, q, { status: 'failed', error: String(e.message || e).slice(0, 300) })
      }
    }
  } catch (e) {
    console.error(videoId, e)
    for (const q of qualities) await setRow(videoId, q, { status: 'failed', error: 'تعذّر قراءة الفيديو الأصلي: ' + String(e.message || e).slice(0, 200) })
  } finally {
    await r2.send(new DeleteObjectCommand({ Bucket, Key: sourceKey })).catch(() => {})
    await rm(dir, { recursive: true, force: true })
  }
}

// One job at a time keeps CPU and disk predictable.
const queue = []
let busy = false
async function pump() {
  if (busy) return
  busy = true
  while (queue.length) { try { await handle(queue.shift()) } catch (e) { console.error(e) } }
  busy = false
}

// A restart loses the in-memory queue, so release rows that would stay "processing" forever.
await sb.from('video_files').update({ status: 'failed', error: 'انقطعت المعالجة، أعد المحاولة' }).eq('status', 'processing')

http.createServer(async (req, res) => {
  if (req.method === 'GET' && req.url === '/health') return res.end('ok')
  if (req.method !== 'POST' || req.url !== '/jobs') return res.writeHead(404).end()
  const given = Buffer.from(String(req.headers['x-worker-secret'] || ''))
  if (given.length !== SECRET.length || !timingSafeEqual(given, SECRET)) return res.writeHead(401).end()
  let body = ''
  for await (const c of req) { body += c; if (body.length > 1e5) return res.writeHead(413).end() }
  let j
  try { j = JSON.parse(body) } catch { return res.writeHead(400).end() }
  const qualities = (Array.isArray(j.qualities) ? j.qualities : []).filter((q) => TARGETS[q]).sort((a, b) => TARGETS[b] - TARGETS[a])
  if (!/^[0-9a-f-]{36}$/.test(j.videoId || '') || !String(j.sourceKey || '').startsWith(`sources/${j.videoId}/`) || !qualities.length) return res.writeHead(400).end()
  queue.push({ videoId: j.videoId, sourceKey: j.sourceKey, qualities })
  res.writeHead(202).end('queued')
  pump()
}).listen(process.env.PORT || 8080, () => console.log('worker ready'))
