// Local check of the conversion logic (needs ffmpeg). Run: node test.mjs
import { execFileSync } from 'node:child_process'
import { mkdtempSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import assert from 'node:assert'
import { probe, decide, transcode } from './convert.mjs'
const d = mkdtempSync(join(tmpdir(), 't-'))
const ff = (...a) => execFileSync('ffmpeg', ['-y', '-v', 'error', ...a])
const mk = (name, size) => { const f = join(d, name); ff('-f', 'lavfi', '-i', `testsrc=size=${size}:rate=24:duration=2`, '-f', 'lavfi', '-i', 'sine=duration=2', '-c:v', 'libx264', '-c:a', 'aac', '-shortest', f); return f }
const dims = async (f) => { const p = await probe(f); return [p.width, p.height] }
const land = mk('land.mp4', '1280x720'), port = mk('port.mp4', '720x1280')
const rot = join(d, 'rot.mp4'); ff('-display_rotation', '90', '-i', land, '-c', 'copy', rot)
assert.deepStrictEqual(await dims(rot), [720, 1280]); console.log('rotated probe ok')
await transcode(land, join(d, 'a.mp4'), { portrait: false, target: 480 }); assert.deepStrictEqual(await dims(join(d, 'a.mp4')), [854, 480]); console.log('landscape 720->480 ok')
await transcode(port, join(d, 'b.mp4'), { portrait: true, target: 480 }); assert.deepStrictEqual(await dims(join(d, 'b.mp4')), [480, 854]); console.log('portrait 1280x720->480 ok')
const pr = await probe(rot); await transcode(rot, join(d, 'c.mp4'), { portrait: pr.portrait, target: 480 }); assert.deepStrictEqual(await dims(join(d, 'c.mp4')), [480, 854]); console.log('rotated phone video ok')
assert.deepStrictEqual([decide(720, 1080), decide(1080, 1080), decide(2160, 1080), decide(2160, 2160)], ['skip', 'copy', 'encode', 'copy']); console.log('decide ok')
