import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
const run = promisify(execFile)

// Quality = size of the SHORT side, so vertical reels (1080x1920) count as 1080p.
export const TARGETS = { '4k': 2160, '2k': 1440, '1080p': 1080, '720p': 720, '480p': 480 }

export async function probe(file) {
  const { stdout } = await run('ffprobe', ['-v', 'error', '-select_streams', 'v:0', '-show_entries', 'stream=width,height:stream_side_data=rotation:stream_tags=rotate', '-of', 'json', file])
  const s = JSON.parse(stdout).streams?.[0]
  if (!s) throw new Error('الملف لا يحتوي على فيديو')
  const rot = Math.abs(Number(s.side_data_list?.find((d) => 'rotation' in d)?.rotation ?? s.tags?.rotate ?? 0)) % 180
  const [width, height] = rot === 90 ? [s.height, s.width] : [s.width, s.height] // as displayed
  return { width, height, short: Math.min(width, height), portrait: height > width }
}

// skip = source is lower than the target (never upscale), copy = source already is that quality, encode = downscale.
export function decide(short, target) {
  if (short < target * 0.95) return 'skip'
  if (short <= target * 1.05) return 'copy'
  return 'encode'
}

export async function transcode(src, out, { portrait, target }) {
  const vf = portrait ? `scale=${target}:-2` : `scale=-2:${target}`
  await run('ffmpeg', ['-y', '-v', 'error', '-i', src, '-map', '0:v:0', '-map', '0:a:0?', '-vf', vf, '-c:v', 'libx264', '-preset', 'medium', '-crf', '18', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', '-movflags', '+faststart', out], { maxBuffer: 1 << 26 })
}
