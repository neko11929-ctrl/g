import { db } from '@/lib/supabase'
import { getUrl } from '@/lib/r2'
import { getLang, T, IG } from '@/lib/i18n'
import { qIndex, qInfo, fmtSize, fmtDur } from '@/lib/q'
import Actions from '@/components/Actions'

export const dynamic = 'force-dynamic'
export const metadata = { robots: { index: false, follow: false }, title: 'COLOR.G7' }

export default async function VideoPage({ params }: { params: { code: string } }) {
  const t = T[getLang()]
  const s = db()
  const { data: v } = await s.from('videos').select('*, video_files(*)').eq('code', params.code).maybeSingle()
  const files = ((v?.video_files as any[]) || []).filter((f) => f.status === 'completed' && qInfo(f.quality)).sort((a, b) => qIndex(a.quality) - qIndex(b.quality))
  if (!v || !v.enabled || (v.expires_at && new Date(v.expires_at) < new Date()) || !files.length) {
    return (
      <main className="mx-auto max-w-xl px-5 pt-16">
        <h1 className="text-2xl">{t.gone}</h1>
        <p className="mt-3 text-neutral-400">{t.goneHint}</p>
      </main>
    )
  }
  await s.rpc('inc_views', { p_id: v.id })
  const smallest = files.reduce((a, b) => (b.size_bytes < a.size_bytes ? b : a))
  const src = await getUrl(smallest.r2_key)
  const poster = v.thumb_key ? await getUrl(v.thumb_key) : undefined
  return (
    <main className="mx-auto max-w-3xl px-5 pb-24 pt-4">
      <video controls playsInline preload="metadata" poster={poster} src={src} className="aspect-video w-full rounded-2xl bg-neutral-950 object-contain" />
      <h1 className="mt-6 text-2xl font-semibold leading-snug">{v.title}</h1>
      {v.duration_sec ? <p dir="ltr" className="mt-1 text-sm text-neutral-500">{fmtDur(v.duration_sec)}</p> : null}
      {v.description ? <p className="mt-3 max-w-prose whitespace-pre-line leading-relaxed text-neutral-400">{v.description}</p> : null}
      <h2 className="mb-3 mt-10 text-sm text-neutral-400">{t.qualities}</h2>
      <div className="flex flex-col gap-3">
        {files.map((f) => {
          const q = qInfo(f.quality)!
          return (
            <a key={f.id} href={`/api/download/${v.code}/${f.quality}`} className="flex h-14 items-center justify-between rounded-2xl border border-neutral-800 bg-neutral-900 px-5 transition hover:bg-white hover:text-black active:scale-[0.98]">
              <span className="font-medium">{t.download} {q.label} <span dir="ltr" className="text-sm opacity-60">{q.sub}</span></span>
              <span dir="ltr" className="text-sm">{fmtSize(f.size_bytes)}</span>
            </a>
          )
        })}
      </div>
      <Actions code={v.code} l={t} ig={IG} />
    </main>
  )
}
