import { getLang, T, IG } from '@/lib/i18n'
export default function Home() {
  const t = T[getLang()]
  return (
    <main className="mx-auto max-w-3xl px-5 pb-24 pt-8">
      <div className="intro flex aspect-[2.39/1] min-h-44 items-center justify-center border border-neutral-800">
        <h1 dir="ltr" className="text-[clamp(1.8rem,9vw,4.2rem)] font-semibold tracking-[0.12em]">COLOR.G7</h1>
      </div>
      <p className="mt-10 text-2xl leading-snug">{t.tagline}</p>
      <p className="mt-4 max-w-prose leading-relaxed text-neutral-400">{t.about}</p>
      <a href={IG} target="_blank" rel="noopener" className="mt-8 inline-flex h-12 items-center rounded-full bg-white px-7 font-medium text-black transition hover:bg-neutral-300 active:scale-95">{t.follow}</a>
      <p dir="ltr" className="mt-4 text-sm text-neutral-500">@color.g7</p>
    </main>
  )
}
