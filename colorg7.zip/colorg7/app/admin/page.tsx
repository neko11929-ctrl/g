import Link from 'next/link'
import { redirect } from 'next/navigation'
import { db, isAdmin } from '@/lib/supabase'
import { fmtSize } from '@/lib/q'
import AdminList from '@/components/AdminList'
export const dynamic = 'force-dynamic'
export default async function Admin() {
  if (!(await isAdmin())) redirect('/admin/login')
  const { data } = await db().from('videos').select('id,code,title,enabled,views,downloads,expires_at,video_files(quality,size_bytes,status,error)').order('created_at', { ascending: false })
  const vids = data ?? []
  const sum = (f: (v: any) => number) => vids.reduce((a, v) => a + f(v), 0)
  const stats: [string, string][] = [
    ['الفيديوهات', String(vids.length)],
    ['المشاهدات', String(sum((v) => v.views))],
    ['التحميلات', String(sum((v) => v.downloads))],
    ['المساحة المستخدمة', fmtSize(sum((v) => v.video_files.reduce((a: number, f: any) => a + Number(f.size_bytes), 0)))],
  ]
  return (
    <main dir="rtl" className="mx-auto max-w-3xl px-5 pb-24">
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        {stats.map(([k, v]) => (
          <div key={k} className="rounded-2xl border border-neutral-800 bg-neutral-900 p-4">
            <p className="text-sm text-neutral-400">{k}</p>
            <p dir="ltr" className="mt-1 text-xl font-semibold">{v}</p>
          </div>
        ))}
      </div>
      <Link href="/admin/new" className="mt-6 inline-flex h-12 items-center rounded-full bg-white px-7 font-medium text-black active:scale-95">إضافة فيديو</Link>
      <AdminList videos={vids} />
    </main>
  )
}
