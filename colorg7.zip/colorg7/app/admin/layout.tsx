import Link from 'next/link'
export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div dir="rtl">
      <nav className="px-5 pb-4"><Link href="/admin" className="text-sm text-neutral-400">لوحة التحكم</Link></nav>
      {children}
    </div>
  )
}
