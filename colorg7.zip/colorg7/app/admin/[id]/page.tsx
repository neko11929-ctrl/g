import { redirect, notFound } from 'next/navigation'
import { db, isAdmin } from '@/lib/supabase'
import VideoForm from '@/components/VideoForm'
export const dynamic = 'force-dynamic'
export default async function Edit({ params }: { params: { id: string } }) {
  if (!(await isAdmin())) redirect('/admin/login')
  let video = null
  if (params.id !== 'new') {
    const { data } = await db().from('videos').select('*, video_files(*)').eq('id', params.id).maybeSingle()
    if (!data) notFound()
    video = data
  }
  return (
    <main dir="rtl" className="mx-auto max-w-xl px-5 pb-24">
      <h1 className="mb-6 text-2xl font-semibold">{video ? 'تعديل الفيديو' : 'فيديو جديد'}</h1>
      <VideoForm video={video} />
    </main>
  )
}
