'use client'
import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { createBrowserClient } from '@supabase/ssr'
export default function Login() {
  const r = useRouter()
  const [email, setEmail] = useState('')
  const [password, setPassword] = useState('')
  const [err, setErr] = useState('')
  async function submit(e: React.FormEvent) {
    e.preventDefault()
    const sb = createBrowserClient(process.env.NEXT_PUBLIC_SUPABASE_URL!, process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!)
    const { error } = await sb.auth.signInWithPassword({ email, password })
    if (error) setErr('البريد أو كلمة المرور غير صحيحة')
    else { r.replace('/admin'); r.refresh() }
  }
  const inp = 'h-12 w-full rounded-xl border border-neutral-800 bg-neutral-900 px-4 outline-none focus:border-white'
  return (
    <main dir="rtl" className="mx-auto max-w-sm px-5 pt-16">
      <h1 className="mb-6 text-2xl font-semibold">دخول المشرف</h1>
      <form onSubmit={submit} className="flex flex-col gap-3">
        <input dir="ltr" type="email" required autoComplete="username" placeholder="البريد الإلكتروني" value={email} onChange={(e) => setEmail(e.target.value)} className={inp} />
        <input dir="ltr" type="password" required autoComplete="current-password" placeholder="كلمة المرور" value={password} onChange={(e) => setPassword(e.target.value)} className={inp} />
        {err && <p role="alert" className="text-sm text-red-400">{err}</p>}
        <button className="h-12 rounded-full bg-white font-medium text-black active:scale-95">دخول</button>
      </form>
    </main>
  )
}
