import { db } from '@/lib/supabase'
import { getUrl } from '@/lib/r2'
export const dynamic = 'force-dynamic'
export async function GET(_: Request, { params }: { params: { code: string; quality: string } }) {
  const s = db()
  const { data: v } = await s.from('videos').select('id,code,enabled,expires_at,video_files(quality,r2_key,status)').eq('code', params.code).maybeSingle()
  const f = (v?.video_files as any[])?.find((x) => x.quality === params.quality && x.status === 'completed')
  if (!v || !v.enabled || (v.expires_at && new Date(v.expires_at) < new Date()) || !f) return new Response('Not found', { status: 404 })
  await s.rpc('inc_downloads', { p_id: v.id })
  const ext = f.r2_key.split('.').pop()
  return Response.redirect(await getUrl(f.r2_key, `COLORG7-${v.code}-${f.quality}.${ext}`), 302)
}
