import { db, isAdmin, deny, fail } from '@/lib/supabase'
import { delObj } from '@/lib/r2'
const FIELDS = ['title', 'description', 'enabled', 'expires_at', 'duration_sec']
export async function PATCH(req: Request, { params }: { params: { id: string } }) {
  if (!(await isAdmin())) return deny()
  const b = await req.json().catch(() => ({}))
  const patch: Record<string, any> = {}
  for (const k of FIELDS) if (k in b) patch[k] = b[k]
  if ('title' in patch && !String(patch.title).trim()) return fail('العنوان مطلوب')
  const { error } = await db().from('videos').update(patch).eq('id', params.id)
  if (error) return fail(error.message, 500)
  return Response.json({ ok: true })
}
export async function DELETE(_: Request, { params }: { params: { id: string } }) {
  if (!(await isAdmin())) return deny()
  const s = db()
  const { data: v } = await s.from('videos').select('thumb_key, video_files(r2_key)').eq('id', params.id).maybeSingle()
  if (v) {
    for (const f of (v.video_files as any[]) || []) await delObj(f.r2_key)
    if (v.thumb_key) await delObj(v.thumb_key)
    await s.from('videos').delete().eq('id', params.id)
  }
  return Response.json({ ok: true })
}
