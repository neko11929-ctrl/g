import { randomBytes } from 'crypto'
import { db, isAdmin, deny, fail } from '@/lib/supabase'
export async function POST(req: Request) {
  if (!(await isAdmin())) return deny()
  const b = await req.json().catch(() => ({}))
  const title = String(b.title || '').trim().slice(0, 200)
  if (!title) return fail('العنوان مطلوب')
  const { data, error } = await db()
    .from('videos')
    .insert({ code: randomBytes(8).toString('base64url'), title, description: String(b.description || '').slice(0, 2000), expires_at: b.expires_at || null, duration_sec: b.duration_sec || null })
    .select('id,code')
    .single()
  if (error) return fail(error.message, 500)
  return Response.json(data)
}
