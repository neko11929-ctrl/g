import { db, isAdmin, deny, fail } from '@/lib/supabase'
import { delObj, sizeOf } from '@/lib/r2'
import { qInfo } from '@/lib/q'
// Called after the browser finished uploading straight to R2: verify the file exists, then record it.
export async function POST(req: Request) {
  if (!(await isAdmin())) return deny()
  const { videoId, kind, quality, key } = await req.json().catch(() => ({}))
  const valid = kind === 'thumb' ? String(key).startsWith(`thumbs/${videoId}-`) : qInfo(quality) && String(key).startsWith(`videos/${videoId}/${quality}-`)
  if (!valid) return fail('بيانات غير صحيحة')
  let size = 0
  try { size = await sizeOf(key) } catch { return fail('الملف لم يصل إلى التخزين') }
  const s = db()
  if (kind === 'thumb') {
    const { data: o } = await s.from('videos').select('thumb_key').eq('id', videoId).single()
    await s.from('videos').update({ thumb_key: key }).eq('id', videoId)
    if (o?.thumb_key && o.thumb_key !== key) await delObj(o.thumb_key)
  } else {
    const { data: o } = await s.from('video_files').select('r2_key').eq('video_id', videoId).eq('quality', quality).maybeSingle()
    const { error } = await s.from('video_files').upsert({ video_id: videoId, quality, r2_key: key, size_bytes: size, status: 'completed' }, { onConflict: 'video_id,quality' })
    if (error) return fail(error.message, 500)
    if (o && o.r2_key !== key) await delObj(o.r2_key)
  }
  return Response.json({ ok: true })
}
export async function DELETE(req: Request) {
  if (!(await isAdmin())) return deny()
  const id = new URL(req.url).searchParams.get('id')
  const s = db()
  const { data: f } = await s.from('video_files').select('r2_key').eq('id', id).maybeSingle()
  if (f) { await delObj(f.r2_key); await s.from('video_files').delete().eq('id', id) }
  return Response.json({ ok: true })
}
