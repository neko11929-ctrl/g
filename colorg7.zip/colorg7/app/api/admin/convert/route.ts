import { db, isAdmin, deny, fail } from '@/lib/supabase'
import { delObj, sizeOf } from '@/lib/r2'
import { qInfo } from '@/lib/q'
// Hands an uploaded original to the FFmpeg worker (a separate server) and marks the qualities as Processing.
export async function POST(req: Request) {
  if (!(await isAdmin())) return deny()
  const { videoId, sourceKey, qualities } = await req.json().catch(() => ({}))
  const qs: string[] = Array.isArray(qualities) ? qualities.filter((q: string) => qInfo(q)) : []
  if (!qs.length || !String(sourceKey).startsWith(`sources/${videoId}/`)) return fail('بيانات غير صحيحة')
  if (!process.env.WORKER_URL || !process.env.WORKER_SECRET) return fail('خادم التحويل غير مُعدّ بعد (WORKER_URL و WORKER_SECRET)', 500)
  try { await sizeOf(sourceKey) } catch { return fail('الملف الأصلي لم يصل إلى التخزين') }
  const s = db()
  const { data: old } = await s.from('video_files').select('r2_key').eq('video_id', videoId).in('quality', qs)
  const rows = qs.map((quality) => ({ video_id: videoId, quality, r2_key: '', size_bytes: 0, status: 'processing', error: null }))
  const { error } = await s.from('video_files').upsert(rows, { onConflict: 'video_id,quality' })
  if (error) return fail(error.message, 500)
  for (const o of old || []) if (o.r2_key) await delObj(o.r2_key)
  try {
    const r = await fetch(process.env.WORKER_URL.replace(/\/$/, '') + '/jobs', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'x-worker-secret': process.env.WORKER_SECRET },
      body: JSON.stringify({ videoId, sourceKey, qualities: qs }),
    })
    if (!r.ok) throw new Error('worker ' + r.status)
  } catch {
    await s.from('video_files').update({ status: 'failed', error: 'تعذّر الاتصال بخادم التحويل' }).eq('video_id', videoId).in('quality', qs)
    return fail('تعذّر الاتصال بخادم التحويل. تأكد أنه يعمل ثم أعد المحاولة.', 502)
  }
  return Response.json({ ok: true })
}
