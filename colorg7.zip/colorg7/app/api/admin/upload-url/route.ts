import { randomBytes } from 'crypto'
import { db, isAdmin, deny, fail } from '@/lib/supabase'
import { putUrl } from '@/lib/r2'
import { qInfo } from '@/lib/q'
const ALLOWED: Record<string, string> = {
  'video/mp4': 'mp4', 'video/quicktime': 'mov', 'video/webm': 'webm', 'video/x-matroska': 'mkv',
  'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp',
}
export async function POST(req: Request) {
  if (!(await isAdmin())) return deny()
  const { videoId, kind, quality, contentType, size } = await req.json().catch(() => ({}))
  const ext = ALLOWED[contentType]
  if (!ext || (kind === 'thumb') !== contentType.startsWith('image/')) return fail('نوع الملف غير مسموح')
  if (kind === 'video' && !qInfo(quality)) return fail('جودة غير معروفة')
  const max = Number(process.env.MAX_UPLOAD_MB || 2048) * 1048576
  if (!size || size > max) return fail('حجم الملف أكبر من الحد المسموح')
  const { data: v } = await db().from('videos').select('id').eq('id', videoId).maybeSingle()
  if (!v) return fail('الفيديو غير موجود', 404)
  const rnd = randomBytes(6).toString('hex')
  const key = kind === 'thumb' ? `thumbs/${videoId}-${rnd}.${ext}` : `videos/${videoId}/${quality}-${rnd}.${ext}`
  return Response.json({ key, url: await putUrl(key, contentType) })
}
