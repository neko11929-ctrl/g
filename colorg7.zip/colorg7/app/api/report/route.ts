import { db, fail } from '@/lib/supabase'
export async function POST(req: Request) {
  const { code } = await req.json().catch(() => ({}))
  const s = db()
  const { data: v } = await s.from('videos').select('id').eq('code', String(code || '')).maybeSingle()
  if (!v) return fail('not found', 404)
  await s.from('reports').insert({ video_id: v.id })
  return Response.json({ ok: true })
}
