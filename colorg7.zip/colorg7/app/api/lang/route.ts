import { NextRequest, NextResponse } from 'next/server'
export function GET(req: NextRequest) {
  const l = req.nextUrl.searchParams.get('l') === 'en' ? 'en' : 'ar'
  const ref = req.headers.get('referer')
  let to = new URL('/', req.url)
  try { if (ref && new URL(ref).origin === to.origin) to = new URL(ref) } catch {}
  const res = NextResponse.redirect(to)
  res.cookies.set('lang', l, { path: '/', maxAge: 31536000 })
  return res
}
