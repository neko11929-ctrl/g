import './globals.css'
import type { Metadata, Viewport } from 'next'
import { Manrope, IBM_Plex_Sans_Arabic } from 'next/font/google'
import Link from 'next/link'
import { getLang } from '@/lib/i18n'

const lat = Manrope({ subsets: ['latin'], variable: '--font-lat' })
const ar = IBM_Plex_Sans_Arabic({ subsets: ['arabic'], weight: ['400', '500', '600'], variable: '--font-ar' })
export const metadata: Metadata = {
  title: 'COLOR.G7',
  description: 'COLOR.G7 — original-quality video downloads',
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || 'http://localhost:3000'),
}
export const viewport: Viewport = { themeColor: '#000000' }

export default function Root({ children }: { children: React.ReactNode }) {
  const lang = getLang()
  return (
    <html lang={lang} dir={lang === 'ar' ? 'rtl' : 'ltr'} className={`${lat.variable} ${ar.variable}`}>
      <body className="min-h-dvh bg-black font-sans antialiased">
        <header className="flex items-center justify-between px-5 py-3">
          <Link href="/" dir="ltr" className="py-2 text-sm font-semibold tracking-[0.18em]">COLOR.G7</Link>
          <a href={`/api/lang?l=${lang === 'ar' ? 'en' : 'ar'}`} className="px-2 py-2 text-sm text-neutral-400 hover:text-white">
            {lang === 'ar' ? 'English' : 'العربية'}
          </a>
        </header>
        {children}
      </body>
    </html>
  )
}
